//
//  SocketClient.h
//  SpiderX
//
//  Created by 陈 卓权 on 13-4-14.
//
//

//#ifndef cocos2d_SocketClient_h
//#define cocos2d_SocketClient_h
//#include "socketcc.h"

//using namespace std;
//
//class SocketClient {
//    TCPClientSocket *m_socket;
//    IPAddress address;
//    pthread_t pthead_rec;
//    
//public:
//    void init();
//    static void* reciveData(void* pthread);
//};


//#endif